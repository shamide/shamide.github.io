'''
3.2.7
Cancer Research Project 
by: Paulina Anzaldo, Sami HAmide
''' 

#importing appropiate libraries for data visualization 
import os.path 
import matplotlib.pyplot as plt 
import plotly.plotly as py

def collect_death_data(): #gathering the data that we need for data visualization
    directory_death = os.path.dirname(os.path.abspath(__file__))  # Extracts data for state death rates
    filename_death = os.path.join(directory_death,"death.csv")
    datafile_death = open(filename_death, 'r')
    data_death = datafile_death.readlines()
    
#put all death rates into a dictionary, and we are separating data into the four regions of the United States. We will put values in a dictionary so we can call each state and get a float version of their death rate.  
    death_rates = {}
    for line in data_death[12:65]:
        state, FIPS, objective, rate = line.split(',') #splits columns by a comma, but we are just using "state" and "rate" 
        death_rates[str(state)] = rate
    Northeast_death_rate = float(death_rates['Connecticut']) + float(death_rates['Maine']) + float(death_rates['Massachusetts']) + float(death_rates['New Hampshire']) + float(death_rates['Rhode Island']) + float(death_rates['Vermont']) + float(death_rates['New Jersey']) + float(death_rates['New York']) + float(death_rates['Pennsylvania']) 
    South_death_rate = float(death_rates['Delaware']) + float(death_rates['Florida']) + float(death_rates['Georgia']) + float(death_rates['Maryland']) + float(death_rates['North Carolina']) + float(death_rates['South Carolina']) + float(death_rates['Virginia']) + float(death_rates['District of Columbia']) + float(death_rates['West Virginia']) + float(death_rates['Alabama']) + float(death_rates['Kentucky']) + float(death_rates['Mississippi']) + float(death_rates['Tennessee']) + float(death_rates['Arkansas']) + float(death_rates['Louisiana']) + float(death_rates['Oklahoma']) + float(death_rates['Texas'])
    West_death_rate = float(death_rates['Arizona']) + float(death_rates['Colorado']) + float(death_rates['Idaho']) + float(death_rates['Montana']) + float(death_rates['Nevada']) + float(death_rates['New Mexico']) + float(death_rates['Utah']) + float(death_rates['Wyoming']) + float(death_rates['Alaska']) + float(death_rates['California']) + float(death_rates['Hawaii']) + float(death_rates['Oregon']) + float(death_rates['Washington'])
    Midwest_death_rate = float(death_rates['Illinois']) + float(death_rates['Indiana']) + float(death_rates['Michigan']) + float(death_rates['Ohio']) + float(death_rates['Wisconsin']) + float(death_rates['Iowa']) + float(death_rates['Kansas']) + float(death_rates['Minnesota']) + float(death_rates['Missouri']) + float(death_rates['Nebraska']) + float(death_rates['North Dakota']) + float(death_rates['South Dakota'])
    return Northeast_death_rate, South_death_rate, West_death_rate, Midwest_death_rate

#put all poverty levels into a dictionary, and we are separating data into the four regions of the United States. We will put values in a dictionary so we can call each state and get a float version of their poverty rate.          

def collect_poverty_data():
    directory_poverty = os.path.dirname(os.path.abspath(__file__)) # Extracts data for state poverty levels
    filename_poverty = os.path.join(directory_poverty,"poverty_levels.csv")
    datafile_poverty = open(filename_poverty, 'r')
    data_poverty = datafile_poverty.readlines()
    
    poverty_levels = {}
    for line in data_poverty[1:]:
        state, level = line.split(',')
        poverty_levels[str(state)] = level
    Northeast_poverty_rate = float(poverty_levels['Connecticut ']) + float(poverty_levels['Maine ']) + float(poverty_levels['Massachusetts ']) + float(poverty_levels['New Hampshire ']) + float(poverty_levels['Rhode Island ']) + float(poverty_levels['Vermont ']) + float(poverty_levels['New Jersey ']) + float(poverty_levels['New York ']) + float(poverty_levels['Pennsylvania ']) 
    South_poverty_rate = float(poverty_levels['Delaware ']) + float(poverty_levels['Florida ']) + float(poverty_levels['Georgia ']) + float(poverty_levels['Maryland ']) + float(poverty_levels['North Carolina ']) + float(poverty_levels['South Carolina ']) + float(poverty_levels['Virginia ']) + float(poverty_levels['District of Columbia ']) + float(poverty_levels['West Virginia ']) + float(poverty_levels['Alabama ']) + float(poverty_levels['Kentucky ']) + float(poverty_levels['Mississippi ']) + float(poverty_levels['Tennessee ']) + float(poverty_levels['Arkansas ']) + float(poverty_levels['Louisiana ']) + float(poverty_levels['Oklahoma ']) + float(poverty_levels['Texas '])
    West_poverty_rate = float(poverty_levels['Arizona ']) + float(poverty_levels['Colorado ']) + float(poverty_levels['Idaho']) + float(poverty_levels['Montana ']) + float(poverty_levels['Nevada ']) + float(poverty_levels['New Mexico ']) + float(poverty_levels['Utah ']) + float(poverty_levels['Wyoming ']) + float(poverty_levels['Alaska ']) + float(poverty_levels['California ']) + float(poverty_levels['Hawaii']) + float(poverty_levels['Oregon ']) + float(poverty_levels['Washington '])
    Midwest_poverty_rate = float(poverty_levels['Illinois ']) + float(poverty_levels['Indiana ']) + float(poverty_levels['Michigan ']) + float(poverty_levels['Ohio ']) + float(poverty_levels['Wisconsin ']) + float(poverty_levels['Iowa ']) + float(poverty_levels['Kansas ']) + float(poverty_levels['Minnesota ']) + float(poverty_levels['Missouri ']) + float(poverty_levels['Nebraska ']) + float(poverty_levels['North Dakota ']) + float(poverty_levels['South Dakota '])
    return Northeast_poverty_rate, South_poverty_rate, West_poverty_rate, Midwest_poverty_rate
    
    
#create a bar graph that shows the death rates per region of the United States   
def create_graph_death(imported_data_death):
    death_rates = imported_data_death
    regions = ['Northeast', 'South', 'West', 'Midwest']
    labels = [1, 2, 3, 4]
    fig, ax = plt.subplots(1,1)
    ax.bar(labels, death_rates)
    plt.locator_params(axis='x',nbins=4)
    ax.set_ylabel('Deaths per one hundred thousand')
    ax.set_xlabel('Regions')
    ax.set_title('Cancer death rates by region')
    ax.set_xticklabels(regions)
    ax = plt.gca() #sets axis colors into purple 
    ax.tick_params(axis='x', colors='purple')
    ax.tick_params(axis='y', colors='purple')
    fig.show()
    
#create a bar graph that shows the poverty rates per region of the United States   
def create_graph_poverty(imported_data_poverty):
    poverty_levels = imported_data_poverty
    regions = ['Northeast', 'South', 'West', 'Midwest']
    labels = [1, 2, 3, 4]
    fig, ax = plt.subplots(1,1)
    ax.bar(labels, poverty_levels)
    plt.locator_params(axis='x',nbins=4)
    ax.set_ylabel('Poverty rates')
    ax.set_xlabel('Regions')
    ax.set_title('Poverty levels by region')
    ax.set_xticklabels(regions)
    ax = plt.gca() #sets axis colors into purple 
    ax.tick_params(axis='x', colors='purple')
    ax.tick_params(axis='y', colors='purple')
    fig.show()

#create 
#main
create_graph_death(collect_death_data())
create_graph_poverty(collect_poverty_data())


    


    
    
    



        
        
    
    

